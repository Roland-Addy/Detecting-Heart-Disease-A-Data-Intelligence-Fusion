from flask import Flask, request, jsonify
import joblib
import numpy as np

app = Flask("model_api")

@app.route('/', methods=['POST'])

def heart_disease_prediction():
    input_json = request.get_json(force=True)

    features = np.array([input_json[feature] for feature in [
        "Sex", "PhysicalHealthDays", "MentalHealthDays", "SleepHours",
        "HeightInMeters", "WeightInKilograms", "GeneralHealth_Fair",
        "GeneralHealth_Good", "GeneralHealth_Very good", "LastCTTime1",
        "LastCTTime2", "LastCTTime3", "PhysicalActivities", "RemovedTeeth1",
        "RemovedTeeth2", "RemovedTeeth3", "HadAngina1", "had_stroke",
        "had_asthma", "had_skin_cancer", "had_copd", "had_depressive_disorder",
        "had_kidney_disease", "had_arthritis", "had_diabetes", "had_diabetes1",
        "had_diabetes2", "deaf_or_hard_of_hearing", "blind_or_vision_difficulty",
        "difficulty_concentrating", "difficulty_walking",
        "difficulty_dressing_bathing", "difficulty_errands", "smoker_status1",
        "smoker_status2", "smoker_status3", "e_cigarette_usage1",
        "e_cigarette_usage2", "e_cigarette_usage3", "chest_scan",
        "race_ethnicity_category1", "race_ethnicity_category2",
        "race_ethnicity_category3", "race_ethnicity_category4", "age_category1",
        "age_category2", "alcohol_drinkers", "hiv_testing", "flu_vax_last_12",
        "pneumo_vax_ever1", "pneumo_vax_ever2", "tetanus_last_10_tdap1",
        "tetanus_last_10_tdap2", "tetanus_last_10_1", "tetanus_last_10_2",
        "high_risk_last_year", "covid_pos1", "covid_pos2"
    ]])

    features = features.reshape(1, -1)

    # Load the heart disease prediction model
    model = joblib.load('model.pkl')

    # Make predictions
    y_probs = model.predict_proba(features)[:, 1]

    if y_probs >= 0.49:
        output = 'Likely to have a heart disease'
    else:
        output = 'Not likely to have a heart disease'

    result = {"prediction": output, "probability": float(y_probs)}

    return jsonify(result)

if __name__ == "__main__":
    app.debug = True
    app.run(host="127.0.0.1", port=5004)
